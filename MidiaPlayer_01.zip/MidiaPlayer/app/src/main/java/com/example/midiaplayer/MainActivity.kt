package com.example.midiaplayer

import android.Manifest
import android.content.ContentUris
import android.content.pm.PackageManager
import android.media.MediaPlayer
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import java.io.IOException

// Agora usando Uri em vez de String
data class Music(val title: String, val artist: String, val uri: Uri)

class MainActivity : AppCompatActivity() {

    private lateinit var musicListContainer: LinearLayout
    private var mediaPlayer: MediaPlayer? = null
    private var currentMusicUri: Uri? = null

    // Guarda o TextView do ícone da música que está tocando (ou pausada)
    private var currentPlayingIconView: TextView? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        musicListContainer = findViewById(R.id.musicListContainer)

        checkPermissionsAndLoadMusic()
    }

    private fun checkPermissionsAndLoadMusic() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(
                    this,
                    Manifest.permission.READ_MEDIA_AUDIO
                ) == PackageManager.PERMISSION_GRANTED
            ) {
                loadMusic()
            } else {
                requestPermissionLauncher.launch(Manifest.permission.READ_MEDIA_AUDIO)
            }
        } else {
            if (ContextCompat.checkSelfPermission(
                    this,
                    Manifest.permission.READ_EXTERNAL_STORAGE
                ) == PackageManager.PERMISSION_GRANTED
            ) {
                loadMusic()
            } else {
                requestPermissionLauncher.launch(Manifest.permission.READ_EXTERNAL_STORAGE)
            }
        }
    }

    private val requestPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { isGranted ->
            if (isGranted) {
                loadMusic()
            } else {
                Toast.makeText(this, "Permissão negada para acessar músicas", Toast.LENGTH_SHORT).show()
            }
        }

    private fun loadMusic() {
        val musicList = mutableListOf<Music>()

        val projection = arrayOf(
            MediaStore.Audio.Media._ID,
            MediaStore.Audio.Media.TITLE,
            MediaStore.Audio.Media.ARTIST
        )

        val selection = "${MediaStore.Audio.Media.IS_MUSIC} != 0"

        val cursor = contentResolver.query(
            MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
            projection,
            selection,
            null,
            MediaStore.Audio.Media.TITLE + " ASC"
        )

        cursor?.use {
            val idIndex = it.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
            val titleIndex = it.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
            val artistIndex = it.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)

            while (it.moveToNext()) {
                val id = it.getLong(idIndex)
                val title = it.getString(titleIndex)
                val artist = it.getString(artistIndex)

                val contentUri = ContentUris.withAppendedId(
                    MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
                    id
                )

                musicList.add(Music(title, artist, contentUri))
            }
        }

        displayMusicList(musicList)
    }

    private fun displayMusicList(musicList: List<Music>) {
        musicListContainer.removeAllViews()

        for (music in musicList) {
            val musicItemLayout = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                setPadding(20, 20, 20, 20)
                setBackgroundColor(0xFFE0E0E0.toInt())

                val layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                )
                layoutParams.setMargins(0, 0, 0, 16)
                this.layoutParams = layoutParams
            }

            val iconView = TextView(this).apply {
                text = "▶︎"
                textSize = 20f
                setPadding(0, 0, 20, 0)
                // Apenas exibição do ícone
            }

            val titleView = TextView(this).apply {
                text = "${music.title} - ${music.artist}"
                textSize = 16f
                setTextColor(0xFF000000.toInt())
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT,
                    1f
                )
            }

            musicItemLayout.addView(iconView)
            musicItemLayout.addView(titleView)

            musicItemLayout.setOnClickListener {
                if (mediaPlayer != null && mediaPlayer?.isPlaying == true && currentMusicUri == music.uri) {
                    // Pausa a música atual
                    mediaPlayer?.pause()
                    iconView.text = "▶︎"
                    Toast.makeText(this@MainActivity, "⏸︎ Pausado: ${music.title}", Toast.LENGTH_SHORT).show()
                    currentPlayingIconView = null
                } else {
                    // Toca nova música
                    playMusic(music)

                    // Reseta ícone anterior para ▶︎
                    currentPlayingIconView?.text = "▶︎"

                    // Atualiza ícone atual para ⏸︎
                    iconView.text = "⏸︎"
                    currentPlayingIconView = iconView
                }
            }

            musicListContainer.addView(musicItemLayout)
        }

        if (musicList.isEmpty()) {
            Toast.makeText(this, "Nenhuma música encontrada", Toast.LENGTH_SHORT).show()
        }
    }

    private fun playMusic(music: Music) {
        try {
            mediaPlayer?.release()

            mediaPlayer = MediaPlayer().apply {
                setDataSource(this@MainActivity, music.uri)
                prepare()
                start()
            }

            currentMusicUri = music.uri
            Toast.makeText(this, "▶︎ Tocando: ${music.title}", Toast.LENGTH_SHORT).show()
        } catch (e: IOException) {
            Toast.makeText(this, "Erro ao tocar: ${music.title}", Toast.LENGTH_SHORT).show()
            e.printStackTrace()
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        mediaPlayer?.release()
        mediaPlayer = null
    }
}
